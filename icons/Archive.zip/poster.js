const amz = require('../amazon/scrape');
const ebay_trading_api = require('./trading');
const request = require('request');
const fs = require('fs');
const a = async () => {
    const x = await amz.scrape('https://www.amazon.ca/Kicking-Horse-Coffee-Power-Roast/dp/B00AE22C4G/')
    const description = createDescription(x);
    fs.writeFileSync('des.html', description);
   //ebay_trading_api.AddFixedPriceItem('','','','','','','','',images=x.images);
    //auth, title, description, sku, price, country , currency, paypal, images, location, itemSpecifics,
    //quantity, brandMPN, site //country = CA, currency= CAD, 
    //fs.writeFileSync('featured_points.txt', x.featured_points );
    //fs.writeFileSync('from_manufacturer.txt', x.from_manufacturer );
    //fs.writeFileSync('prod_details.txt', x.prod_details );
    //fs.writeFileSync('prod_description.txt', x.prod_description );
}

a()

const createDescription = (listing) => {
    let description = '';
    if(listing.foundList.featured_points) {
        description = description + formatData(listing.featured_points);
    }

    if(listing.foundList.from_manufacturer) {
        description = description + formatData(listing.from_manufacturer);
    }

    if(listing.foundList.prod_details) {
        description = description + formatData(listing.prod_details);
    }

    if(listing.foundList.prod_description) {
        description = description + formatData(listing.prod_description);
    }

    return description;
}

const formatData = (data) => {
    let formattedData = data;
    if(typeof data == 'string' ) {
        formattedData = formattedData.replace(/^\s*[\r\n]/gm, '');
    }

    if(typeof data == 'object' && data instanceof Array) {
        formattedData = '<div><ul style="list-style-type:disc;">'
        for(i = 0; i < data.length; i++) {
            formattedData = formattedData + '<li>' + data[i] + '</li>';
        }
        formattedData = formattedData + '</ul></div>';
    }
    return formattedData;

}


const db = require('../dropbox/api.js');
const b = async() => {
    // const a = await db.getDropboxLink('https://images-na.ssl-images-amazon.com/images/I/61E1VYkFYlL._AC_SL1500_.jpg', '61E1VYkFYlL._AC_SL1500_.jpg');
    // console.log(a)
    let url = 'https://www.dropbox.com/s/hdp281ry3uv4gip/61E1VYkFYlL._AC_SL1500_.jpg?raw=1';
    const r = request(url, (err, response) => {
        //console.log(r.uri)
        console.log(response.request.uri)
      })
    //db.deleteDropboxPicture(a.path);
}

//b()
