const path = require('path');
const fs = require('fs');
const EbayAuthToken = require('oauth-ebay');
const Ebay = require('ebay-node-api');
var eBay = require('ebay-node-client');
const https = require('https')


const scopes = ["https://api.ebay.com/oauth/api_scope",
    "https://api.ebay.com/oauth/api_scope/sell.marketing",
    "https://api.ebay.com/oauth/api_scope/sell.inventory",
    "https://api.ebay.com/oauth/api_scope/sell.account",
    "https://api.ebay.com/oauth/api_scope/sell.fulfillment",
    "https://api.ebay.com/oauth/api_scope/sell.analytics.readonly",
    "https://api.ebay.com/oauth/api_scope/sell.finances"
];


const readApiCreds = () => {
    try {
        return JSON.parse(fs.readFileSync('./api_creds.json'));
    } catch (err) {
        console.log(err);
    }

}
exports.readApiCreds = readApiCreds;
const getURL = () => {
    const keys = readApiCreds();
    ebayAuthToken = new EbayAuthToken({
        clientId: keys.app,
        clientSecret: keys.cert,
        scope: scopes,
        redirectUri: keys.ru
    });

    return ebayAuthToken.getUserConsentUrl();
}

exports.getURL = getURL;

const getRefreshToken = (code) => {
    const keys = readApiCreds();
    ebayAuthToken = new EbayAuthToken({
        clientId: keys.app,
        clientSecret: keys.cert,
        scope: scopes,
        redirectUri: keys.ru
    });
    ebayAuthToken.getAuthorizationCodeToken(code).then((data) => {
        const date = new Date();
        const data_with_expiry = {
            ...data,
            auth_expiry: date.getTime() + 7100000
        }
        fs.writeFileSync(
            path.join(settings_path, 'refresh.json'),
            JSON.stringify(data_with_expiry)
        );
    }).catch((error) => {
        console.log(`Error to get Access token :${JSON.stringify(error)}`);
    });

}
exports.getRefreshToken = getRefreshToken;
//console.log(getURL());

const getAuthToken = (cb) => {
    const keys = readApiCreds();
    const date = new Date();
    ebayAuthToken = new EbayAuthToken({
        clientId: keys.app,
        clientSecret: keys.cert,
        scope: scopes,
        redirectUri: keys.ru
    });
    const content = JSON.parse(fs.readFileSync('./refresh.json'));
    if(content.auth_expiry > date.getTime()) {
        cb(content.access_token);
    } else {
        const refresh = content.refresh_token;
        ebayAuthToken.getAccessTokenWithRefresh(refresh).then((data) => {
            const data_with_expiry = {
                ...data,
                auth_expiry: date.getTime() + 7100000
            }
            fs.writeFileSync(
                './refresh.json',
                JSON.stringify(data_with_expiry)
            );
            cb(data_with_expiry.access_token);
        }).catch((error) => {
            console.log(`Error to get Access token from refresh token:${JSON.stringify(error)}`);
        });
    }
}
exports.getAuthToken = getAuthToken;

const searchItemByKeyword = async (keywords, countryCode) => {
    //Get countryCodes from this website:
    //https://developer.ebay.com/devzone/finding/callref/Enums/GlobalIdList.html
    let ebay = new Ebay({
        clientID:  readApiCreds().app,
        limit: 50,
        countryCode: countryCode
    });
    ebay.findItemsByKeywords(keywords).then((data) => {
        //console.log(data[0].searchResult[0].item);
        console.log(data[0].searchResult[0]);
        console.log(data[0].paginationOutput[0]);
    }, (error) => {
        console.log(error);
    });
}
exports.searchItemByKeyword = searchItemByKeyword;

//Get Orders:
const getOrders = async () => {
    getAuthToken((token) => {
        fetch('https://api.ebay.com/sell/fulfillment/v1/order/', {
            method: 'GET',
            //body: JSON.stringify({}),
            headers: {
                'Authorization': 'Bearer ' + token
            }
        })
        .then(response => response.json())
        .then(data => console.log(data));
    });

}
