const key = require('./api');

const request = require('request');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');




//uploadImage(path.resolve(__dirname, '61E1VYkFYlL._SL1500_.jpg'));



const getBase64FromURL = async (url) => {
    return new Promise(async (resolve, reject) => {
        var request = require('request').defaults({ encoding: null });
        request.get(url, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            data = "data:" + 'image/jpeg' + ";base64," + new Buffer.from(body).toString('base64');
            resolve(data)
        }
        });
    })
}

const base64_encode = (file)  => {
    // read binary data
    var bitmap = fs.readFileSync(path.resolve(__dirname, '61E1VYkFYlL._SL1500_.jpeg'));
    // convert binary data to base64 encoded string
    return 'data:image/jpeg;base64' + new Buffer(bitmap).toString('base64');
}
const uploadImage = async (url, name, filename) => {
    return new Promise(async(resolve, reject) => {
        //const encoded_data = await getBase64FromURL(url);
        const encoded_data = base64_encode('asdf');
        fs.writeFileSync('pic.txt',encoded_data);
        var keys = key.readApiCreds();
        var mimeBoundary = 'MIME_boundary';

        var xml =
        `
        <?xml version="1.0" encoding="utf-8"?>
        <UploadSiteHostedPicturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
        <RequesterCredentials>
            <eBayAuthToken>ABC...123</eBayAuthToken>
        </RequesterCredentials>
        <WarningLevel>High</WarningLevel>
        </UploadSiteHostedPicturesRequest>
        `
        let $ = cheerio.load(xml, {
            xmlMode: true
        })
        $('eBayAuthToken').text(keys.authnauth);

        let firstPart = '';
        firstPart += '--' + mimeBoundary + '\r\n';
        firstPart += 'Content-Disposition: form-data; name=\"XML Payload\"' + '\r\n';
        //firstPart += 'Content-Type: text/xml;charset=utf-8' + '\r\n\r\n';
        firstPart += $.xml();
        firstPart += '\r\n\r\n';

        //console.log(firstPart)
        let secondPart = '--' + mimeBoundary + '\r\n';
        secondPart += 'Content-Disposition: form-data; name="'+ name + '"; filename="'+filename+ '"'+ '\r\n';
        secondPart += 'Content-Type: image/jpeg'+ '\r\n\r\n';
        secondPart += encoded_data + '\r\n\r\n';
        secondPart += '--' + mimeBoundary;

        var body = firstPart + secondPart;
        fs.writeFileSync('pic.txt', body)

        request.post({
            url: "https://api.ebay.com/ws/api.dll",
            port: 443,
            method: "POST",
            headers: {
                'Content-Type': 'multipart/form-data; boundary=' + mimeBoundary,
                'X-EBAY-API-COMPATIBILITY-LEVEL': '911',
                'X-EBAY-API-DEV-NAME': keys.dev,
                'X-EBAY-API-APP-NAME': keys.app,
                'X-EBAY-API-CERT-NAME': keys.cert,
                'X-EBAY-API-SITEID': '2',
                'X-EBAY-API-CALL-NAME': 'UploadSiteHostedPictures'
            },
            body: body
        },
        (error, response, body) => {
            console.log(body)
            resolve({
                error: error,
                response: response,
                body: body
            })
        });

    })
}

const postToEbay = async (callname, bodyXml) => {
    return new Promise((resolve, reject) => {
        keys = key.readApiCreds();
        request.post({
                url: "https://api.ebay.com/ws/api.dll",
                port: 443,
                method: "POST",
                headers: {
                    'Content-Type': 'application/xml',
                    'X-EBAY-API-COMPATIBILITY-LEVEL': '911',
                    'X-EBAY-API-DEV-NAME': keys.dev,
                    'X-EBAY-API-APP-NAME': keys.app,
                    'X-EBAY-API-CERT-NAME': keys.cert,
                    'X-EBAY-API-SITEID': '2',
                    'X-EBAY-API-CALL-NAME': callname
                },
                body: bodyXml
            },
            (error, response, body) => {
                resolve({
                    error: error,
                    response: response,
                    body: body
                })
            });
    })

}

const getSuggestedCategory = async (title) => {
    return new Promise((resolve, reject) => {
        keys = key.readApiCreds();
        let xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<GetSuggestedCategoriesRequest xmlns=\"urn:ebay:apis:eBLBaseComponents\">\r\n  <RequesterCredentials>\r\n    <eBayAuthToken>ABC...123<\/eBayAuthToken>\r\n  <\/RequesterCredentials>\r\n  <Query>camera<\/Query>\r\n<\/GetSuggestedCategoriesRequest>"
        let $ = cheerio.load(xml, {
            xmlMode: true
        })

        $('eBayAuthToken').text(keys.authnauth);
        $('query').text(title);
        postToEbay(`GetSuggestedCategories`, $.xml()).then((reply) => {
            $ = cheerio.load(reply.body, {
                xmlMode: true
            })
            resolve($('CategoryID').first().text());
        });
    })
}
exports.getSuggestedCategory = getSuggestedCategory;


const UploadSiteHostedPictures = async (url) => {
    var xml =
        `
    <?xml version="1.0" encoding="utf-8"?>
    <UploadSiteHostedPicturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
      <RequesterCredentials>
        <eBayAuthToken>ABC...123</eBayAuthToken>
      </RequesterCredentials>
      <WarningLevel>High</WarningLevel>
      <ExternalPictureURL>https://go.developer.ebay.com/sites/default/files/assets/hero.jpg</ExternalPictureURL>
      <PictureSet>Standard</PictureSet>
      <PictureName>Developer Page Banner</PictureName>
    </UploadSiteHostedPicturesRequest>
    `
    keys = key.readApiCreds();
    let $ = cheerio.load(xml, {
        xmlMode: true
    })
    $('eBayAuthToken').text(keys.authnauth);
    $('ExternalPictureURL').text(url);

    postToEbay(`UploadSiteHostedPictures`, $.xml()).then((reply) => {
        $ = cheerio.load(reply.body, {
            xmlMode: true
        })
        console.log(reply);
    });
}
//UploadSiteHostedPictures('https://doc-04-6c-docs.googleusercontent.com/docs/securesc/ha0ro937gcuc7l7deffksulhg5h7mbp1/gti7qhu9odugatl6ig5pemdhgmc8kuam/1580083200000/15379585837040019384/*/1k4GJXt-mn8OT0aWyFotjyE7CSeTZECP-')

const AddFixedPriceItem = async (auth, title, description, sku, price, country, currency, paypal, images, location, itemSpecifics,
    quantity, brandMPN, site) => {
    var xml =
        `
    <?xml version="1.0" encoding="utf-8"?>
    <AddFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">
    <RequesterCredentials>
    <eBayAuthToken>YOURTOKENHERE</eBayAuthToken>
    </RequesterCredentials>
    <ErrorLanguage>en_CA</ErrorLanguage>
    <WarningLevel>High</WarningLevel>
    <Item>
    <AutoPay>true</AutoPay>
    <UseTaxTable>true</UseTaxTable>
    <Title>Apple MacBook Pro MB990LL/A 13.3 in. Notebook NEW</Title>
    <Description>Brand New Apple MacBook Pro MB990LL/A 13.3 in. Notebook!</Description>
    <PrimaryCategory>
    <CategoryID>111422</CategoryID>
    </PrimaryCategory>
    <SKU> SKUType (string) </SKU>
    <StartPrice>500.0</StartPrice>
    <CategoryMappingAllowed>true</CategoryMappingAllowed>
    <ConditionID>1000</ConditionID>
    <Country>CA</Country>
    <Currency>CAD</Currency>
    <DispatchTimeMax>3</DispatchTimeMax>
    <ListingDuration>GTC</ListingDuration>
    <ListingType>FixedPriceItem</ListingType>
    <PaymentMethods>PayPal</PaymentMethods>
    <PayPalEmailAddress>dropstore007@gmail.com</PayPalEmailAddress>
    <PictureDetails>
    <GalleryType>Gallery</GalleryType>
    <PhotoDisplay>PicturePack</PhotoDisplay>

    </PictureDetails>
    <ItemSpecifics></ItemSpecifics>
    <Location>Toronto, Ontario</Location>
    <ProductListingDetails>
    <BrandMPN></BrandMPN>
    <IncludeStockPhotoURL>true</IncludeStockPhotoURL>
    <IncludeeBayProductDetails>false</IncludeeBayProductDetails>
    <UseFirstProduct>true</UseFirstProduct>
    <UseStockPhotoURLAsGallery>true</UseStockPhotoURLAsGallery>
    <ReturnSearchResultOnDuplicates>true</ReturnSearchResultOnDuplicates>
    </ProductListingDetails>
    <Quantity>1</Quantity>
    <ReturnPolicy>
    <ReturnsAcceptedOption>ReturnsAccepted</ReturnsAcceptedOption>
    <RefundOption>MoneyBack</RefundOption>
    <ReturnsWithinOption>Days_30</ReturnsWithinOption>
    <ShippingCostPaidByOption>Seller</ShippingCostPaidByOption>
    </ReturnPolicy>
    <ShippingDetails>
    <ShippingType>Flat</ShippingType>
    <ShippingServiceOptions>
    <ShippingServicePriority>1</ShippingServicePriority>
    <ShippingService>CA_StandardShipping</ShippingService>
    <FreeShipping>true</FreeShipping>
    <ShippingServiceAdditionalCost currencyID="CAD">0.00</ShippingServiceAdditionalCost>
    </ShippingServiceOptions>
    </ShippingDetails>
    <Site>Canada</Site>
    </Item>
    </AddFixedPriceItemRequest>
    `
    const $ = cheerio.load(xml, {
        xmlMode: true
    })
    $('eBayAuthToken').text(auth);
    $('Title').text(title);
    $('Description').text(description);
    $('SKU').text(sku);
    $('StartPrice').text(price);
    $('Country').text(country);
    $('Currency').text(currency);
    $('PayPalEmailAddress').text(paypal);
    $('Location').text(location);
    $('ItemSpecifics').text(itemSpecifics);
    $('Quantity').text(quantity);
    $('BrandMPN').text(brandMPN);
    $('Site').text(site);



    for (i = 0; i < images.length; i++) {
        $('PhotoDisplay').append('<PictureURL>'+ images[i] +'</PictureURL>');
    }



}
exports.AddFixedPriceItem = AddFixedPriceItem;
